const { validatePlaylistPayload } = require('../validator/playlistsValidator');
const { addPlaylists, getPlaylists, deletePlaylist } = require('../services/playlists');
const { authenticate } = require('../auth/authMiddleware');

const postPlaylistHandler = async (request, h) => {
  try {
    const userId = authenticate(request);
    validatePlaylistPayload(request.payload);

    const playlistId = await addPlaylists(request.payload.name, userId);
    return h.response({
      status: 'success',
      message: 'Playlist berhasil dibuat',
      data: { playlistId },
    }).code(201);
  } catch (error) {
    const status = error.name === 'Unauthorized' ? 401 : error.name === 'ValidationError' ? 400 : 500;
    return h.response({
      status: status === 500 ? 'error' : 'fail',
      message: error.message,
    }).code(status);
  }
};

const getPlaylistsHandler = async (request, h) => {
  try {
    const userId = authenticate(request);
    const playlists = await getPlaylists(userId);
  
    return h.response({
      status: 'success',
      data: { playlists },
    });
  } catch (error) {
    return h.response({
      status: 'fail',
      message: error.message,
    }).code(error.name === 'Unauthorized' ? 401 : 500);
  }
};
  
const deletePlaylistHandler = async (request, h) => {
  try {
    const userId = authenticate(request);
    const { id } = request.params;
  
    await deletePlaylist(id, userId);
    return h.response({
      status: 'success',
      message: 'Playlist berhasil dihapus',
    });
  } catch (error) {
    const status = error.name === 'Forbidden' ? 403 : error.name === 'Unauthorized' ? 401 : 500;
    return h.response({
      status: 'fail',
      message: error.message,
    }).code(status);
  }
};
  
module.exports = {
  postPlaylistHandler,
  getPlaylistsHandler,
  deletePlaylistHandler,
};